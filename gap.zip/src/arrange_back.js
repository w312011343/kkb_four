import BrowserWindow from 'sketch-module-web-view';
import tool from './tool.js';
import sketch from 'sketch';
var arrange = {
  init: function (context, path, options = {}){
    let browserWindow = new BrowserWindow(options);
    browserWindow.loadURL(path);

    tool.panelPositon(context,browserWindow);


    browserWindow.webContents.on('updateGap', function (data) {
      if (!data || (data && !data.type)) {
          return;
      }
      let currentContext = tool.uploadContext(context) || context;
      let params = {
        context: currentContext,
        data:data,
        groupFlag:false,
        group:null
      }
      arrange.createGroup(params);
      let group = params.group;
      if (!group) return;
      switch (data.type) {
        // 水平
        case "horizontal":
          arrange.horizontal(currentContext,group, data.value);
          break;
        // 垂直
        case "vertical":
          arrange.vertical(currentContext,group,data.value);
          break;
        default:
          console.log('未处理');
          break;
      }
      // 重选group
      if (params.groupFlag) {
        context.document.currentPage().changeSelectionBySelectingLayers([group]);
      }
      // 计算group选框大小
      group.resizeToFitChildrenWithOption(0);
      // 赋值
      arrange.setAttr(context,group,data);
    });
    browserWindow.webContents.on('toolbar', function (data) {
      if (!data || (data && !data.type)) {
          return;
      }
      switch (data.type) {
        case "1":
        console.log(11);
          break;
        case "2":
        console.log(222);
          break;
        default:
          console.log('未处理');
          break;
      }
    });
  },
  createGroup: function (params){
    let sels = params.context.selection;
    if (sels.length < 1) {
      sketch.UI.message("请至少选择两个对象");
    } else if (sels.length == 1) {
      if (String(sels[0].className()) === 'MSLayerGroup') {
        params.group = sels[0];
      }else{
        sketch.UI.message("请至少选择两个对象");
      }
    }else{
      let group = MSLayerGroup.new();
      let parent = sels[0].parentGroup();
      group.frame = MSRect.rectWithRect(NSMakeRect(0, 0, 100, 100)); 
      group.name = 'group ' + params.data.type + " " + params.data.value;
      tool.addLayers(group,sels);
      parent.addLayer(group);
      params.group = group;
      params.groupFlag = true;
    }
  },
  horizontal:function(context,group,value){
    let layers = group.layers();
    let sortLayer = layers.sort(tool.sortObjKey('x','frame'));
    for (let i = 1; i < sortLayer.length;i++){
      sortLayer[i].frame().setX(tool.bound(sortLayer[i - 1]).right+ value);
    }
  },
  vertical: function (context, group, value){
    let layers = group.layers();
    let sortLayer = layers.sort(tool.sortObjKey('y', 'frame'));
    for (let i = 1; i < sortLayer.length; i++) {
      sortLayer[i].frame().setY(tool.bound(sortLayer[i - 1]).bottom + value);
    }
  },
  setAttr: function (context, group, data) {
    var groupData = tool.getAttr({obj:group,attr:'Arrange'}) || {};
    groupData[data.type] = data.value;
    tool.setAttr({obj:group,attr:'Arrange',value:groupData});
  },
  updatePos:function(context,sels){

  }
}
export default arrange;