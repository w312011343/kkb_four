import Settings from 'sketch/settings';
/**
    *文件用途说明:工具类
    *方法目录以及说明：
        openUploadPanel:打开上传的属性面板
        layerToImage:对应内容转成图片
        sketchPath:获取sketch的路径
        writeContentsToFile:内容写入文件中
        getAllDocumentSymbols:获取当前文档中所有的symbol
        setAttr:设置对象自定义属性方法
        getAttr:获取对象自定义属性方法
        getServerData:获取服务器的数据
        toJson:转换成json格式
**/
var tool = {
  /**
     * [openUploadPanel  打开上传面板]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  fileTypes  类型过滤
     * }
    */
  openUploadPanel: function (params) {
    let panel = NSOpenPanel.openPanel();
    let self = this;
    panel.setAllowsMultipleSelection(0);
    panel.setCanChooseDirectories(0);
    panel.setCanChooseFiles(1);
    panel.setFloatingPanel(1);
    panel.setMessage('Choose file');
    var result = panel.runModalForDirectory_file_types(nil, nil, params.fileTypes);
    if (result !== NSOKButton) {
      return 0;
    }
    if (panel.URLs().count() < 1) {
      return 0;
    }
    let path = panel.URLs().objectAtIndex(0).path();
    let contents = NSString.stringWithContentsOfFile_encoding_error(path, NSUTF8StringEncoding, false);
    let data = self.transform(contents);
    return data;
  },
  /**
     * [layerToImage  对应内容导成图片]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  path    图片保存路径+名字
     *  name    图片名字
     *  context 当前sketch内容
     *  type    类型,默认是png，可以省略,
     *  obj     对应元素
     * }
    */
  layerToImage: function (params) {
    var slice = MSExportRequest.exportRequestsFromExportableLayer(params.obj).firstObject();
    slice.setShouldTrim(1);
    slice.setScale(1);
    params.context.document.saveArtboardOrSlice_toFile(slice, params.path);
  },
  /**
     * [sketchPath  对应插件路径，绝对路径，type不存在的时候指向到Contents/Sketch]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  type       可以省略，如果为script,则表示获取的是当前sketch运行文件的路径
     *  context
     * }
    */
  sketchPath: function (params) {
    let path = params.context.scriptPath.stringByDeletingLastPathComponent();
    if (params.type === 'script') {
      // stringByDeletingLastPathComponent 去除最后一个路径
      path = params.context.scriptPath.stringByDeletingLastPathComponent();
    }
    return path;
  },
  /**
     * [writeContentsToFile 将内容写入文件中]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  path     写入路径
     *  content  写入的内容
     * }
    */
  writeContentsToFile: function (params) {
    var jsContentNSSString = NSString.stringWithFormat(params.content);
    jsContentNSSString.writeToFile_atomically_encoding_error(params.path, true, NSUTF8StringEncoding, null);
  },
  /**
     * [getAllDocumentSymbols 获取当前文档里面的所有symbol]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  context  写入的内容
     * }
    */
  getAllDocumentSymbols: function (params) {
    var pages = params.context.document.pages();
    var symbols = [];
    for (var i = 0; i < pages.count(); i++) {
      var page = pages.objectAtIndex(i);
      for (var k = 0; k < page.layers().count(); k++) {
        var layer = page.layers().objectAtIndex(k);
        var className = layer.class() + '';
        if (className === 'MSSymbolMaster') {
          symbols.push(layer);
        }
      }
    }
    return symbols;
  },
  /**
     * [getResourcePath 资源路径]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  context
     * }
    */
  getResourcePath: function (context) {
    var pluginPath = NSString.stringWithFormat('%@', context.scriptPath.replace(/\/(\w*)\.cocoascript$/, ''));
    while (pluginPath.lastPathComponent().pathExtension() !== 'sketchplugin') {
      pluginPath = pluginPath.stringByDeletingLastPathComponent();
    }
    return pluginPath + '/Contents/Resources';
  },
  /**
     * [setAttr 设置对象的自定义属性]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  obj    当前选中对象
     *  attr   设置的属性
     *  value  设置的值
     *  type   默认为空，表示的是layer，document对象
     * }
    */
  setAttr: function (params) {
    if (params.type === 'document') {
      Settings.setDocumentSettingForKey(params.obj, params.attr, params.value);
    } else {
      Settings.setLayerSettingForKey(params.obj, params.attr, params.value);
    }
  },
  /**
     * [getAttr 获取对象的自定义属性]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  obj    当前选中对象
     *  attr   设置的属性
     *  type   默认为空，表示的是layer，document对象
     * }
    */
  getAttr: function (params) {
    let value = null;
    if (params.type === 'document') {
      value = Settings.documentSettingForKey(params.obj, params.attr);
    } else {
      value = Settings.layerSettingForKey(params.obj, params.attr);
    }
    return value;
  },
  /**
     * [getServerData 获取服务器数据]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  type    类型 GET/POST
     *  path   路径
     *  context
     * }
    */
  getServerData: function (params) {
    var request = NSMutableURLRequest.alloc().init();
    var self = this;
    request.setHTTPMethod_(params.type);
    request.setURL_(NSURL.URLWithString_(params.path));
    var responseData = NSURLConnection.sendSynchronousRequest_returningResponse_error_(request, nil, nil);
    var stringResponse = NSString.alloc().initWithData_encoding_(responseData, NSUTF8StringEncoding);
    var json = JSON.parse(stringResponse);
    if (json.success) {
      json = json.content;
      var path = self.sketchPath({ context: params.context, type: 'script' }) + '/data.json';
      self.writeContentsToFile({ path: path, content: JSON.stringify(json) });
    }
    return json;
  },
  /**
     * [getServerFile 获取下载文件到指定路径]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  type    类型 GET/POST
     *  path   路径
     *  context
     * }
    */
  getServerFile: function (params) {
    var request = NSMutableURLRequest.alloc().init();
    request.setHTTPMethod_(params.type);
    request.setURL_(NSURL.URLWithString_(params.path));
    let splitArr = params.path.split('/');
    let path = tool.sketchPath({ context: params.context, type: 'script' }) + '/libs/' + splitArr[splitArr.length - 1];
    var responseData = NSURLConnection.sendSynchronousRequest_returningResponse_error_(request, nil, nil);
    NSFileManager.defaultManager().createFileAtPath_contents_attributes(path, responseData, null);
  },
  /**
     * [toJson 指定对象转json]
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  obj    当前对象
     * }
    */
  toJson: function (params) {
    const artboardImm = params.obj.immutableModelObject();
    const string = MSJSONDataArchiver.archiveStringWithRootObject_error(artboardImm, null);
    var json = JSON.parse(string);
    return json;
  },
  /**
     * [rgbaToHex 颜色对象转成十六进制颜色]
     * @param {[object]} colorObj [object] 对应color数据对象
     */
  rgbaToHex: function (colorObj) {
    var a = Math.round(colorObj.alpha * 255).toString(16);
    var r = colorObj.red > 1 ? colorObj.red.toString(16) : Math.round(colorObj.red * 255).toString(16);
    var g = colorObj.green > 1 ? colorObj.green.toString(16) : Math.round(colorObj.green * 255).toString(16);
    var b = colorObj.blue > 1 ? colorObj.blue.toString(16) : Math.round(colorObj.blue * 255).toString(16);
    if (a.length === 1) a = '0' + a;
    if (r.length === 1) r = '0' + r;
    if (g.length === 1) g = '0' + g;
    if (b.length === 1) b = '0' + b;
    return '#' + a + r + g + b;
  },
  /**
     * [setAttr 获取对象的自定义属性]
     * @param {[object]} obj [object]  对应元素
     * @param {[object]} value [object]  对应值
     * @param {[object]} params [object]  对应数据对象
     * params = {
     *  type    类型 system/theme
     *  colorId   颜色id
     *  themeId     主题id
     *  value       颜色值
     *  context
     *  attr    修改属性 Fills/
     * }
    */
  typeConfig: function (obj, value, attr) {
    let attrChange = {
      'Fills': {
        MSTextLayer: obj.setTextColor,
        MSShapePathLayer: obj.style().borders && obj.style().borders().length && obj.style().borders()[0] && obj.style().borders()[0].setColor,
        default: obj.style().fills && obj.style().fills().length && obj.style().fills()[0] && obj.style().fills()[0].setColor
      }
    };
    let colorVal = MSImmutableColor.colorWithSVGString(value).newMutableCounterpart();
    let fnName = attrChange[attr][obj.className() + ''] || attrChange[attr]['default'];
    fnName(colorVal);
  },
  /**
     * [getArrayIndex 获取数据下标]
     * @param {[object]} data [object]  当前数据
     * @param {[Array]} arr [Array]  数组
    */
  getArrayIndex: function (data, arr) {
    let val = -1;
    arr.forEach(function (item, index) {
      if (item === data) {
        val = index;
        return false;
      }
    });
    return val;
  },
  /**
        * [uploadContext 更新选中context]
        * @param {[object]} context [object]  对应数据对象
        * }
    */
  uploadContext: function (context) {
    let contextNow = context;
    contextNow.document = NSDocumentController.sharedDocumentController().currentDocument();
    contextNow.selection = context.document.selectedLayers().layers();
    return contextNow;
  },
  /**
        * [panelPositon 属性面板位置控制，靠近原生面板]
        * @param {[object]} context [object]  对应数据对象
        * @param {[object]} browserWindow [object]  对应面板对象
        * }
    */
  panelPositon: function (context, browserWindow) {
    let windowFrame = context.document.window().frame();

    let splitView = context.document.splitViewController().splitView();

    let spiltFrame = splitView.frame();

    let spiltViewHeight = windowFrame.origin.y + spiltFrame.size.height;

    let size = browserWindow.getSize();

    let x = windowFrame.origin.x + windowFrame.size.width - 240 - size[0];
    browserWindow.setPosition(x, spiltViewHeight);
  },
  bound:function(obj){
    let frame = obj.frame();
    return {
      left:frame.x(),
      right:frame.x()+frame.width(),
      top:frame.y(),
      bottom:frame.y()+frame.height()
    }
  },
  /**
      * [sortObjKey 数组对象排序]
      * 用法：objArr.sort(tool.sortObjKey(prop,flag));
      * @param {[String]}    prop [需要对比的属性]x/y
      * @param {[String]}    flag [标示，标示获取的对象属性]eg:frame表示是获取frame对象上面的属性
      *
  */
  sortObjKey: function (prop,flag) {
    return function (obj1, obj2) {
      let value1 = null;
      let value2 = null;
      if (flag === 'frame') {
        value1 = obj1.frame()[prop];
        value2 = obj2.frame()[prop];
      }else{
        value1 = obj1[prop];
        value2 = obj2[prop];
      }
      return value1 - value2;
    }
  },
  /**
    * [addLayers 移动元素位置] siblingLayer.removeFromParent()
    * @param {[object]}    parent 需要增加的容器
    * @param {[object]}    obj 对应元素,可以是数组，也可以是单个元素
    *
  */
  addLayers:function(parent,obj,flag){
    if (!obj.length) {
      obj = [obj];
    }
    if (!obj.length) {
      return;
    }
    for(let i = 0;i<obj.length;i++){
      obj[i].removeFromParent();
      parent.addLayer(obj[i]);
    }
  },
  /**
    * [getTargetParentArr 获取指定类型的父类]
    * @param {[object]} params [object]  对应数据对象
     * params = {
     *  obj    当前对象
     *  targetType    指定类型  MSLayerGroup/MSArtboardGroup...
     *  wrapType      遍历截止目标类型  MSLayerGroup/MSArtboardGroup..
     * flag            true，表示收集遍历的数组对象，默认没有
     * }
    *
  */
  getTargetParent:function(params){
      let obj = params.obj;
      let target = null;
      let cycle = function(obj){
        let group = obj.parentGroup();
        if (group.isMemberOfClass(params.wrapType)) {
            target = group;
          return target;
        }else{
          return cycle(group);
        }
      }
      target = cycle(obj);
  }
};
export default tool;
