import BrowserWindow from 'sketch-module-web-view';
import tool from './tool.js';
import sketch from 'sketch/dom';
var UI = require('sketch/ui');
var Settings = require('sketch/settings')
var arrange = {
  space: function (context) {
    let sels = context.selection;
    let data = {
      left: {
        value: 10,
        attr: 'test'
      },
      right: {
        value: 24,
        attr: 'whz'
      }
    }
    if (sels.length < 0 || sels.length > 1) {
      UI.message("只能选中一个对象设置");
      return;
    }
    let parent = sels[0].parentGroup();
    if (String(parent.className()) === 'MSPage') {
      UI.message("父类不能是页面！！！");
      return;
    }
    let name = 'group_';
    let st = sels[0];
    let stSketch = sketch.fromNative(st);
    let constraints = {};
    let group = null;
    let isSpace = Settings.layerSettingForKey(stSketch, 'isSpace') || false;
    if (String(st.className()) === 'MSLayerGroup') {
      // 修改里面的参数
      group = st;
      constraints = Settings.layerSettingForKey(stSketch, 'constraints') || {};
    } else {
      // 创建group
      group = MSLayerGroup.new();
      group.frame = MSRect.rectWithRect(NSMakeRect(0, 0, 100, 100));
      // group.name = name+"i";
      st.removeFromParent();
      group.addLayer(st);
      parent.addLayer(group);
      let sketchGroup = sketch.fromNative(group);
      sketchGroup.adjustToFit();
      context.document.currentPage().changeSelectionBySelectingLayers([group]);
    }
    constraints.parent = constraints.parent || {};
    constraints.parent.id = parent.objectID() + "";
    constraints.parent.data = constraints.parent.data || {};
    for (let key in data) {
      constraints.parent.data[key] = {
        value: data[key].value,
        attr: data[key].attr,
        id: group.objectID() + ""
      }
      name += key + "_" + data[key].value;
    }
    group.name = name;
    Settings.setLayerSettingForKey(group, "constraints", constraints);
    Settings.setLayerSettingForKey(group, "isSpace", true)
    arrange.updateSpace(parent, group, constraints.parent.data);
  },
  updateSpace(parent, group, data,flag) {
    let parentW = parent.frame().width();
    let parentH = parent.frame().height();
    let x = data.left && data.left.value || null;
    let y = data.top && data.top.value || null;
    if (data.left && data.right) {
      let groupW = parentW - data.left.value - data.right.value;
      group.frame().setWidth(groupW);
    } else if (data.left || data.right) {
      x = x || (parentW - group.frame().width() - data.right.value);
    } else if (data.top && data.bottom) {
      let groupH = parentH - data.top.value - data.bottom.value;
      group.frame().setHeight(groupH);
    } else if (data.top && data.bottom) {
      y = y || (parentH - group.frame().height() - data.bottom.value);
    }
    if (x || x === 0) {
      x = flag === 'stack'?parent.frame().x()+x:x;
      group.frame().setX(x);
    }
    if (y || y === 0) {
      y = flag === 'stack'?parent.frame().y()+y:y;
      group.frame().setY(y);
    }
  },
  siblings(context) {
    let sels = context.selection;
    let data = {
      value: 50,
      attr: 'test',
      type: "horizontal",
      aside: 'top'
    }
    if (sels.length > 0 && sels.length <3) {
      UI.message("只能选中两个对象设置");
      return;
    }
    let firstSel = sels[0];
    let sketchFirstSel = sketch.fromNative(firstSel);
    let isSiblings = Settings.layerSettingForKey(sketchFirstSel, "isSiblings") || false;
    let origin = sels[0];
    let target = sels[1];
    let constraints = Settings.layerSettingForKey(sketchFirstSel, 'constraints') || {};
    let siblings = constraints.siblings || {};
    let parent = sels[0].parentGroup();
    let group = null;
    if (sels.length ===1) {
      if(!isSiblings){
        UI.message("选中一个对象只能是已经设置过兄弟关系的group才行");
        return;
      }
      origin = arrange.getChildrenById(firstSel,siblings.origin);
      target = arrange.getChildrenById(firstSel,target.origin);
      group = firstSel;
    }
    let gapW = 0;
    let gapH = 0;
    if (data.type === 'vertical') {
      gapH = origin.frame().height() + data.value + origin.frame().y();
    } else if (data.type === 'horizontal') {
      gapW = origin.frame().width() + data.value + origin.frame().x();
    }
    gapW && target.frame().setX(gapW);
    gapH && target.frame().setY(gapH);
    let aside = data.aside;
    if (aside === 'top') {
      target.frame().setY(origin.frame().y());
    } else if (aside === 'bottom') {
      target.frame().setY(origin.frame().y() + origin.frame().height());
    } else if (aside === 'left') {
      target.frame().setX(origin.frame().x());
    } else if (aside === 'right') {
      target.frame().setX(origin.frame().x() + origin.frame().width());
    }
    if (sels.length !==1) {
      group = MSLayerGroup.new();
      group.frame = MSRect.rectWithRect(NSMakeRect(0, 0, 100, 100));
      // group.name = name+"i";
      origin.removeFromParent();
      group.addLayer(origin);
      target.removeFromParent();
      group.addLayer(target);
      parent.addLayer(group);
    }
    let sketchGroup = sketch.fromNative(group);
    group.name = "group_" + data.type + "_" + data.value + "_" + data.aside;
    sketchGroup.adjustToFit();
    context.document.currentPage().changeSelectionBySelectingLayers([group]);
    Settings.setLayerSettingForKey(group, "isSiblings", true);
    constraints.siblings = {
      value: data.value,
      attr: data.attr,
      type: data.type,
      aside: data.aside,
      origin: origin.objectID() + "",
      target: target.objectID() + ""
    }
    Settings.setLayerSettingForKey(sketchGroup, "constraints", constraints);
  },
  stack(context) {
    let sels = context.selection;
    let data = {
      left: {
        value: 12,
        attr: 'test'
      },
      right: {
        value: 12,
        attr: 'whz'
      }
    }
    if(sels.length < 0){
      UI.message("至少选中一个对象");
      return;
    }
   
    let parent = sels[0].parentGroup();
    let firstSel = sels[0];
    let sketchFirstSel = sketch.fromNative(firstSel);
    let isStack = Settings.layerSettingForKey(sketchFirstSel, "isStack") || false;
     // 获取底层
     let targetLayer = sels[0];
     let constraints = constraintsSettings.layerSettingForKey(sketchFirstSel, "constraints") || {};
     let stack = constraints.stack || {};
     let group = null;
     let sketchTargetLayer = sketch.fromNative(targetLayer);
     let children = sels;
    if (sels.length  === 1) {
      if(!isStack){
        UI.message("选中一个对象只能是已经设置过层叠关系的group才行");
        return;
      }
      group = firstSel;
      targetLayer = arrange.getChildrenById(firstSel,stack.id);
      children = firstSel.layers();
    }else{
      for (let i = 1; i < sels.length; i++) {
        if (sketch.fromNative(targetLayer).index > sketch.fromNative(sels[i]).index) {
          targetLayer = sels[i];
        }
      }
      if (!(sketchTargetLayer.type === 'ShapePath' || sketchTargetLayer.type === 'Image')) {
        UI.message("底部元素不是shape或者image");
        return;
      }
       // 创建group
      group = MSLayerGroup.new();
      let name = "group_";
      group.frame = MSRect.rectWithRect(NSMakeRect(0, 0,100, 200));
      // group.name = name+"i";
      constraints.stack = constraints.stack || {};
      constraints.stack.id = sketchTargetLayer.id;
      constraints.stack.data = constraints.stack.data || {};
      parent.addLayer(group);
    }
    for (let key in data) {
      constraints.stack.data[key] = {
        value: data[key].value,
        attr: data[key].attr
      }
      name += key + "_" + data[key].value;
    }
    let constraintData = constraints.stack.data;
    for (let i = 0; i < children.length; i++) {
      let st = children[i];
      if (String(st.objectID()) !== sketchTargetLayer.id) {
        arrange.updateSpace(targetLayer, st, constraintData,'stack');
      }
      if(sels.length !== 1){
        st.removeFromParent();
        group.addLayer(st);
      }
    }
    let sketchGroup = sketch.fromNative(group);
    sketchGroup.adjustToFit();
    group.name = name;
    Settings.setLayerSettingForKey(group, "constraints", constraints);
    Settings.setLayerSettingForKey(group, "isStack", true)
  },
  getChildrenById(parent,id){
    let layers = parent.layers();
    if(layers && layers.length){
      for(let i = 0;i<layers.length;i++){
        if(String(layers[i].objectID()) === id){
          return layers[i];
        }
      }
    }
  },
}
export default arrange;