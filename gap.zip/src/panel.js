import arrange from "./arrange.js";
// function onRun(context) {
//   let options = {
//     width: 500,
//     height: 400,
//     identifier: 'ucd.uiplus.eco.panel.arrange',
//     backgroundColor: '#bbbbbb',
//     alwaysOnTop: true
//   };
//   let path = '../Resources/panel.html';
//   arrange.init(context, path, options);
// }
function onRun(context) {
  let options = {
    width: 500,
    height: 400,
    identifier: 'ucd.uiplus.eco.panel.arrange',
    backgroundColor: '#bbbbbb',
    alwaysOnTop: true
  };
  debugger;
  //let path = '../Resources/toolbar.html';
  //arrange.init(context, "", options);

 // arrange.space(context);

//  arrange.siblings(context);
arrange.stack(context);
}
function onSelectionChangedFinish(context) {
  // console.log(1111);
  // debugger;
  // var sels = context.actionContext.newSelection;
  // if (!sels.length) return;
  // arrange.updatePos(context.acitonContext, sels);
}
export default onRun;
export { onSelectionChangedFinish};